package jobsheet3;

public class demoUser {
    public static void main(String[] args) {
        user user1 = new user("annisa.nadya", "Annisa Nadya", "annisa.nadya@gmail.com");

        user1.cetakInfo();
    }
}
